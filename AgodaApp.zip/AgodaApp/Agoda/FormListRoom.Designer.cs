﻿namespace Agoda
{
    partial class FormListRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonPaletteListRoom = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.kryptonPanelThanhCongCu = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonButtonDangKy = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButtonDangNhap = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.kryptonPanel1 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonDateTimePickerDi = new ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker();
            this.kryptonDateTimePickerDen = new ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker();
            this.kryptonTextBoxSearch = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.kryptonButtonSoNguoiPhong = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanelThanhCongCu)).BeginInit();
            this.kryptonPanelThanhCongCu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).BeginInit();
            this.kryptonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPaletteListRoom
            // 
            this.kryptonPaletteListRoom.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteListRoom.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteListRoom.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPaletteListRoom.FormStyles.FormMain.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this.kryptonPaletteListRoom.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderCommon.StateCommon.ButtonPadding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.Border.Rounding = 10;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 12;
            this.kryptonPaletteListRoom.HeaderStyles.HeaderForm.StateCommon.ButtonPadding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            // 
            // kryptonPanelThanhCongCu
            // 
            this.kryptonPanelThanhCongCu.Controls.Add(this.kryptonButtonDangKy);
            this.kryptonPanelThanhCongCu.Controls.Add(this.kryptonButtonDangNhap);
            this.kryptonPanelThanhCongCu.Controls.Add(this.pictureBoxLogo);
            this.kryptonPanelThanhCongCu.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonPanelThanhCongCu.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanelThanhCongCu.Name = "kryptonPanelThanhCongCu";
            this.kryptonPanelThanhCongCu.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.kryptonPanelThanhCongCu.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonLowProfile;
            this.kryptonPanelThanhCongCu.Size = new System.Drawing.Size(1484, 60);
            this.kryptonPanelThanhCongCu.TabIndex = 2;
            // 
            // kryptonButtonDangKy
            // 
            this.kryptonButtonDangKy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonDangKy.Location = new System.Drawing.Point(1317, 3);
            this.kryptonButtonDangKy.Name = "kryptonButtonDangKy";
            this.kryptonButtonDangKy.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonButtonDangKy.Size = new System.Drawing.Size(133, 45);
            this.kryptonButtonDangKy.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonButtonDangKy.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonButtonDangKy.StateCommon.Border.Color1 = System.Drawing.Color.Aqua;
            this.kryptonButtonDangKy.StateCommon.Border.Color2 = System.Drawing.Color.Aqua;
            this.kryptonButtonDangKy.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonDangKy.StateCommon.Border.Rounding = 20;
            this.kryptonButtonDangKy.StateCommon.Border.Width = 1;
            this.kryptonButtonDangKy.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.LightCoral;
            this.kryptonButtonDangKy.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonDangKy.StateCommon.Content.ShortText.Hint = ComponentFactory.Krypton.Toolkit.PaletteTextHint.AntiAlias;
            this.kryptonButtonDangKy.TabIndex = 2;
            this.kryptonButtonDangKy.Values.Text = "Đăng Ký";
            // 
            // kryptonButtonDangNhap
            // 
            this.kryptonButtonDangNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonDangNhap.Location = new System.Drawing.Point(1178, 3);
            this.kryptonButtonDangNhap.Name = "kryptonButtonDangNhap";
            this.kryptonButtonDangNhap.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonButtonDangNhap.Size = new System.Drawing.Size(133, 45);
            this.kryptonButtonDangNhap.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonButtonDangNhap.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonButtonDangNhap.StateCommon.Border.Color1 = System.Drawing.Color.Coral;
            this.kryptonButtonDangNhap.StateCommon.Border.Color2 = System.Drawing.Color.Aqua;
            this.kryptonButtonDangNhap.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonDangNhap.StateCommon.Border.Rounding = 20;
            this.kryptonButtonDangNhap.StateCommon.Border.Width = 1;
            this.kryptonButtonDangNhap.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.DodgerBlue;
            this.kryptonButtonDangNhap.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonDangNhap.StateCommon.Content.ShortText.Hint = ComponentFactory.Krypton.Toolkit.PaletteTextHint.AntiAlias;
            this.kryptonButtonDangNhap.TabIndex = 1;
            this.kryptonButtonDangNhap.Values.Text = "Đăng nhập";
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxLogo.Image = global::Agoda.Properties.Resources.Agoda_logo;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(125, 57);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            this.pictureBoxLogo.Click += new System.EventHandler(this.pictureBoxLogo_Click);
            // 
            // kryptonPanel1
            // 
            this.kryptonPanel1.Controls.Add(this.kryptonButtonSoNguoiPhong);
            this.kryptonPanel1.Controls.Add(this.pictureBoxSearch);
            this.kryptonPanel1.Controls.Add(this.kryptonTextBoxSearch);
            this.kryptonPanel1.Controls.Add(this.kryptonDateTimePickerDi);
            this.kryptonPanel1.Controls.Add(this.kryptonDateTimePickerDen);
            this.kryptonPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonPanel1.Location = new System.Drawing.Point(0, 60);
            this.kryptonPanel1.Name = "kryptonPanel1";
            this.kryptonPanel1.Size = new System.Drawing.Size(1484, 71);
            this.kryptonPanel1.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(39)))), ((int)(((byte)(77)))));
            this.kryptonPanel1.TabIndex = 3;
            // 
            // kryptonDateTimePickerDi
            // 
            this.kryptonDateTimePickerDi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonDateTimePickerDi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.kryptonDateTimePickerDi.Location = new System.Drawing.Point(683, 17);
            this.kryptonDateTimePickerDi.Name = "kryptonDateTimePickerDi";
            this.kryptonDateTimePickerDi.Size = new System.Drawing.Size(175, 42);
            this.kryptonDateTimePickerDi.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonDateTimePickerDi.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonDateTimePickerDi.StateCommon.Border.Rounding = 10;
            this.kryptonDateTimePickerDi.StateCommon.Border.Width = 1;
            this.kryptonDateTimePickerDi.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonDateTimePickerDi.TabIndex = 5;
            // 
            // kryptonDateTimePickerDen
            // 
            this.kryptonDateTimePickerDen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonDateTimePickerDen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.kryptonDateTimePickerDen.Location = new System.Drawing.Point(480, 17);
            this.kryptonDateTimePickerDen.Name = "kryptonDateTimePickerDen";
            this.kryptonDateTimePickerDen.Size = new System.Drawing.Size(175, 42);
            this.kryptonDateTimePickerDen.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonDateTimePickerDen.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonDateTimePickerDen.StateCommon.Border.Rounding = 10;
            this.kryptonDateTimePickerDen.StateCommon.Border.Width = 1;
            this.kryptonDateTimePickerDen.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonDateTimePickerDen.TabIndex = 4;
            // 
            // kryptonTextBoxSearch
            // 
            this.kryptonTextBoxSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.kryptonTextBoxSearch.Location = new System.Drawing.Point(133, 17);
            this.kryptonTextBoxSearch.Multiline = true;
            this.kryptonTextBoxSearch.Name = "kryptonTextBoxSearch";
            this.kryptonTextBoxSearch.Size = new System.Drawing.Size(309, 42);
            this.kryptonTextBoxSearch.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonTextBoxSearch.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonTextBoxSearch.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonTextBoxSearch.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBoxSearch.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonTextBoxSearch.StateCommon.Border.Rounding = 10;
            this.kryptonTextBoxSearch.StateCommon.Border.Width = 1;
            this.kryptonTextBoxSearch.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.kryptonTextBoxSearch.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBoxSearch.StateCommon.Content.Padding = new System.Windows.Forms.Padding(70, 5, -1, 10);
            this.kryptonTextBoxSearch.TabIndex = 7;
            this.kryptonTextBoxSearch.Text = "ccc";
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBoxSearch.Image = global::Agoda.Properties.Resources.search_icon;
            this.pictureBoxSearch.Location = new System.Drawing.Point(143, 24);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(30, 30);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSearch.TabIndex = 9;
            this.pictureBoxSearch.TabStop = false;
            // 
            // kryptonButtonSoNguoiPhong
            // 
            this.kryptonButtonSoNguoiPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonSoNguoiPhong.Location = new System.Drawing.Point(899, 17);
            this.kryptonButtonSoNguoiPhong.Name = "kryptonButtonSoNguoiPhong";
            this.kryptonButtonSoNguoiPhong.Size = new System.Drawing.Size(358, 42);
            this.kryptonButtonSoNguoiPhong.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.Rounding = 10;
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, 5, -1);
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.Black;
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.Black;
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonSoNguoiPhong.TabIndex = 10;
            this.kryptonButtonSoNguoiPhong.Values.Text = "2 người, 1 phòng";
            // 
            // FormListRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1484, 861);
            this.Controls.Add(this.kryptonPanel1);
            this.Controls.Add(this.kryptonPanelThanhCongCu);
            this.Name = "FormListRoom";
            this.Palette = this.kryptonPaletteListRoom;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StateCommon.Back.Color1 = System.Drawing.Color.White;
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanelThanhCongCu)).EndInit();
            this.kryptonPanelThanhCongCu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).EndInit();
            this.kryptonPanel1.ResumeLayout(false);
            this.kryptonPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPaletteListRoom;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanelThanhCongCu;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDangKy;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDangNhap;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel1;
        private ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker kryptonDateTimePickerDi;
        private ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker kryptonDateTimePickerDen;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSearch;
        private System.Windows.Forms.PictureBox pictureBoxSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonSoNguoiPhong;
    }
}