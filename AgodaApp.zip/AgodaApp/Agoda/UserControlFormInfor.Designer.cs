﻿namespace Agoda
{
    partial class UserControlFormInfor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelImgPhong = new System.Windows.Forms.Panel();
            this.groupBoxThongTinCHung = new System.Windows.Forms.GroupBox();
            this.labelTenChung = new System.Windows.Forms.Label();
            this.labelThongTinchung = new System.Windows.Forms.Label();
            this.labelDiaChi = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelSao = new System.Windows.Forms.Label();
            this.groupBoxDanhGiaChung = new System.Windows.Forms.GroupBox();
            this.labelDanhGia = new System.Windows.Forms.Label();
            this.labelLuotDanhGia = new System.Windows.Forms.Label();
            this.webView21 = new Microsoft.Web.WebView2.WinForms.WebView2();
            this.groupBoxTienNghi = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panelImgPhong.SuspendLayout();
            this.groupBoxThongTinCHung.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxDanhGiaChung.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.webView21)).BeginInit();
            this.groupBoxTienNghi.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelImgPhong
            // 
            this.panelImgPhong.Controls.Add(this.pictureBox6);
            this.panelImgPhong.Controls.Add(this.pictureBox7);
            this.panelImgPhong.Controls.Add(this.pictureBox4);
            this.panelImgPhong.Controls.Add(this.pictureBox5);
            this.panelImgPhong.Controls.Add(this.pictureBox3);
            this.panelImgPhong.Controls.Add(this.pictureBox2);
            this.panelImgPhong.Controls.Add(this.pictureBox1);
            this.panelImgPhong.Location = new System.Drawing.Point(93, 40);
            this.panelImgPhong.Name = "panelImgPhong";
            this.panelImgPhong.Size = new System.Drawing.Size(1015, 260);
            this.panelImgPhong.TabIndex = 7;
            // 
            // groupBoxThongTinCHung
            // 
            this.groupBoxThongTinCHung.Controls.Add(this.labelSao);
            this.groupBoxThongTinCHung.Controls.Add(this.labelDiaChi);
            this.groupBoxThongTinCHung.Controls.Add(this.labelThongTinchung);
            this.groupBoxThongTinCHung.Controls.Add(this.labelTenChung);
            this.groupBoxThongTinCHung.Location = new System.Drawing.Point(93, 336);
            this.groupBoxThongTinCHung.Name = "groupBoxThongTinCHung";
            this.groupBoxThongTinCHung.Size = new System.Drawing.Size(616, 208);
            this.groupBoxThongTinCHung.TabIndex = 8;
            this.groupBoxThongTinCHung.TabStop = false;
            // 
            // labelTenChung
            // 
            this.labelTenChung.AutoSize = true;
            this.labelTenChung.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenChung.Location = new System.Drawing.Point(20, 23);
            this.labelTenChung.Name = "labelTenChung";
            this.labelTenChung.Size = new System.Drawing.Size(205, 29);
            this.labelTenChung.TabIndex = 0;
            this.labelTenChung.Text = "Khách sạn Camy";
            // 
            // labelThongTinchung
            // 
            this.labelThongTinchung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThongTinchung.Location = new System.Drawing.Point(22, 120);
            this.labelThongTinchung.Name = "labelThongTinchung";
            this.labelThongTinchung.Size = new System.Drawing.Size(516, 58);
            this.labelThongTinchung.TabIndex = 1;
            this.labelThongTinchung.Text = "Hãy để chuyến đi của quý khách có một khởi đầu tuyệt vời khi ở lại khách sạn này," +
    " nơi có Wi-Fi miễn phí trong tất cả các phòng.";
            // 
            // labelDiaChi
            // 
            this.labelDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDiaChi.ForeColor = System.Drawing.Color.Blue;
            this.labelDiaChi.Location = new System.Drawing.Point(21, 86);
            this.labelDiaChi.Name = "labelDiaChi";
            this.labelDiaChi.Size = new System.Drawing.Size(268, 34);
            this.labelDiaChi.TabIndex = 3;
            this.labelDiaChi.Text = "QL1K, Linh Xuân, Thủ Đức";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(748, 138);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(195, 115);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(748, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(195, 115);
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(523, 138);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(195, 115);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(523, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(195, 115);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(292, 138);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(195, 115);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(292, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(195, 115);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 250);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelSao
            // 
            this.labelSao.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSao.ForeColor = System.Drawing.Color.Yellow;
            this.labelSao.Location = new System.Drawing.Point(19, 52);
            this.labelSao.Name = "labelSao";
            this.labelSao.Size = new System.Drawing.Size(268, 34);
            this.labelSao.TabIndex = 5;
            this.labelSao.Text = "⭐⭐";
            // 
            // groupBoxDanhGiaChung
            // 
            this.groupBoxDanhGiaChung.Controls.Add(this.webView21);
            this.groupBoxDanhGiaChung.Controls.Add(this.labelLuotDanhGia);
            this.groupBoxDanhGiaChung.Controls.Add(this.labelDanhGia);
            this.groupBoxDanhGiaChung.Location = new System.Drawing.Point(793, 336);
            this.groupBoxDanhGiaChung.Name = "groupBoxDanhGiaChung";
            this.groupBoxDanhGiaChung.Size = new System.Drawing.Size(315, 335);
            this.groupBoxDanhGiaChung.TabIndex = 9;
            this.groupBoxDanhGiaChung.TabStop = false;
            // 
            // labelDanhGia
            // 
            this.labelDanhGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDanhGia.Location = new System.Drawing.Point(17, 16);
            this.labelDanhGia.Name = "labelDanhGia";
            this.labelDanhGia.Size = new System.Drawing.Size(100, 23);
            this.labelDanhGia.TabIndex = 0;
            this.labelDanhGia.Text = "Tuyệt vời";
            // 
            // labelLuotDanhGia
            // 
            this.labelLuotDanhGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLuotDanhGia.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.labelLuotDanhGia.Location = new System.Drawing.Point(17, 43);
            this.labelLuotDanhGia.Name = "labelLuotDanhGia";
            this.labelLuotDanhGia.Size = new System.Drawing.Size(100, 23);
            this.labelLuotDanhGia.TabIndex = 1;
            this.labelLuotDanhGia.Text = "1,000 đánh giá";
            // 
            // webView21
            // 
            this.webView21.AllowExternalDrop = true;
            this.webView21.CreationProperties = null;
            this.webView21.DefaultBackgroundColor = System.Drawing.Color.White;
            this.webView21.Location = new System.Drawing.Point(21, 86);
            this.webView21.Name = "webView21";
            this.webView21.Size = new System.Drawing.Size(263, 231);
            this.webView21.TabIndex = 2;
            this.webView21.ZoomFactor = 1D;
            // 
            // groupBoxTienNghi
            // 
            this.groupBoxTienNghi.Controls.Add(this.label7);
            this.groupBoxTienNghi.Controls.Add(this.label8);
            this.groupBoxTienNghi.Controls.Add(this.label4);
            this.groupBoxTienNghi.Controls.Add(this.label5);
            this.groupBoxTienNghi.Controls.Add(this.label6);
            this.groupBoxTienNghi.Controls.Add(this.label3);
            this.groupBoxTienNghi.Controls.Add(this.label2);
            this.groupBoxTienNghi.Controls.Add(this.label1);
            this.groupBoxTienNghi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxTienNghi.Location = new System.Drawing.Point(96, 571);
            this.groupBoxTienNghi.Name = "groupBoxTienNghi";
            this.groupBoxTienNghi.Size = new System.Drawing.Size(613, 100);
            this.groupBoxTienNghi.TabIndex = 10;
            this.groupBoxTienNghi.TabStop = false;
            this.groupBoxTienNghi.Text = "Tiện nghi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(44, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "✔️ wifi miễn phí";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "✔️ Nhà hàng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(351, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "✔️ Đỗ xe free";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(351, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "✔️ Vườn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "✔️ Đưa đón";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "✔️ Hồ bơi";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(498, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "✔️ Phòng tập";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(498, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "✔️ Dịch vụ phòng";
            // 
            // UserControlFormInfor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.groupBoxTienNghi);
            this.Controls.Add(this.groupBoxDanhGiaChung);
            this.Controls.Add(this.groupBoxThongTinCHung);
            this.Controls.Add(this.panelImgPhong);
            this.Name = "UserControlFormInfor";
            this.Size = new System.Drawing.Size(1203, 800);
            this.panelImgPhong.ResumeLayout(false);
            this.groupBoxThongTinCHung.ResumeLayout(false);
            this.groupBoxThongTinCHung.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxDanhGiaChung.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.webView21)).EndInit();
            this.groupBoxTienNghi.ResumeLayout(false);
            this.groupBoxTienNghi.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelImgPhong;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBoxThongTinCHung;
        private System.Windows.Forms.Label labelTenChung;
        private System.Windows.Forms.Label labelThongTinchung;
        private System.Windows.Forms.Label labelDiaChi;
        private System.Windows.Forms.Label labelSao;
        private System.Windows.Forms.GroupBox groupBoxDanhGiaChung;
        private System.Windows.Forms.Label labelLuotDanhGia;
        private System.Windows.Forms.Label labelDanhGia;
        private Microsoft.Web.WebView2.WinForms.WebView2 webView21;
        private System.Windows.Forms.GroupBox groupBoxTienNghi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
