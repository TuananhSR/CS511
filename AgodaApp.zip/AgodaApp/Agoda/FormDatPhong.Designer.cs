﻿namespace Agoda
{
    partial class FormDatPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonPaletteDatPhong = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.kryptonGroupThongTinCaNhan = new ComponentFactory.Krypton.Toolkit.KryptonGroup();
            this.label1 = new System.Windows.Forms.Label();
            this.kryptonButtonDatPhong = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonDropButtonQuocGia = new ComponentFactory.Krypton.Toolkit.KryptonDropButton();
            this.kryptonTextBoxSDT = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxNhapLaiEmail = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEmail = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxHoTen = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelQuocGia = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelSDT = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabel5 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelNhapLaiEmail = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEmail = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelHoTen = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabel1 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupThongTinCaNhan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupThongTinCaNhan.Panel)).BeginInit();
            this.kryptonGroupThongTinCaNhan.Panel.SuspendLayout();
            this.kryptonGroupThongTinCaNhan.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPaletteDatPhong
            // 
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Back.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPaletteDatPhong.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderCommon.StateCommon.ButtonPadding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.Border.Rounding = 12;
            this.kryptonPaletteDatPhong.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            // 
            // kryptonGroupThongTinCaNhan
            // 
            this.kryptonGroupThongTinCaNhan.Location = new System.Drawing.Point(279, 97);
            this.kryptonGroupThongTinCaNhan.Name = "kryptonGroupThongTinCaNhan";
            // 
            // kryptonGroupThongTinCaNhan.Panel
            // 
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.label1);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonButtonDatPhong);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonDropButtonQuocGia);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonTextBoxSDT);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonTextBoxNhapLaiEmail);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonTextBoxEmail);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonTextBoxHoTen);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabelQuocGia);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabelSDT);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabel5);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabelNhapLaiEmail);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabelEmail);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabelHoTen);
            this.kryptonGroupThongTinCaNhan.Panel.Controls.Add(this.kryptonLabel1);
            this.kryptonGroupThongTinCaNhan.Size = new System.Drawing.Size(879, 678);
            this.kryptonGroupThongTinCaNhan.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 310);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(809, 55);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nếu quý khách nhập địa chỉ thư điện tử và không hoàn thành việc đặt phòng thì chú" +
    "ng tôi có thể nhắc nhở để giúp quý khách tiếp tục đặt phòng.";
            // 
            // kryptonButtonDatPhong
            // 
            this.kryptonButtonDatPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonDatPhong.Location = new System.Drawing.Point(226, 594);
            this.kryptonButtonDatPhong.Name = "kryptonButtonDatPhong";
            this.kryptonButtonDatPhong.Size = new System.Drawing.Size(426, 50);
            this.kryptonButtonDatPhong.StateCommon.Back.Color1 = System.Drawing.Color.DodgerBlue;
            this.kryptonButtonDatPhong.StateCommon.Back.Color2 = System.Drawing.Color.DodgerBlue;
            this.kryptonButtonDatPhong.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonDatPhong.StateCommon.Border.Rounding = 10;
            this.kryptonButtonDatPhong.StateCommon.Border.Width = 1;
            this.kryptonButtonDatPhong.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.kryptonButtonDatPhong.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonDatPhong.TabIndex = 12;
            this.kryptonButtonDatPhong.Values.Text = "Đặt phòng";
            // 
            // kryptonDropButtonQuocGia
            // 
            this.kryptonDropButtonQuocGia.Location = new System.Drawing.Point(476, 408);
            this.kryptonDropButtonQuocGia.Name = "kryptonDropButtonQuocGia";
            this.kryptonDropButtonQuocGia.Size = new System.Drawing.Size(361, 29);
            this.kryptonDropButtonQuocGia.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonDropButtonQuocGia.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonDropButtonQuocGia.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonDropButtonQuocGia.TabIndex = 11;
            this.kryptonDropButtonQuocGia.Values.Text = "Việt Nam";
            // 
            // kryptonTextBoxSDT
            // 
            this.kryptonTextBoxSDT.Location = new System.Drawing.Point(33, 408);
            this.kryptonTextBoxSDT.Name = "kryptonTextBoxSDT";
            this.kryptonTextBoxSDT.Size = new System.Drawing.Size(360, 29);
            this.kryptonTextBoxSDT.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBoxSDT.TabIndex = 10;
            // 
            // kryptonTextBoxNhapLaiEmail
            // 
            this.kryptonTextBoxNhapLaiEmail.Location = new System.Drawing.Point(31, 260);
            this.kryptonTextBoxNhapLaiEmail.Name = "kryptonTextBoxNhapLaiEmail";
            this.kryptonTextBoxNhapLaiEmail.Size = new System.Drawing.Size(806, 29);
            this.kryptonTextBoxNhapLaiEmail.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBoxNhapLaiEmail.TabIndex = 9;
            // 
            // kryptonTextBoxEmail
            // 
            this.kryptonTextBoxEmail.Location = new System.Drawing.Point(31, 179);
            this.kryptonTextBoxEmail.Name = "kryptonTextBoxEmail";
            this.kryptonTextBoxEmail.Size = new System.Drawing.Size(806, 29);
            this.kryptonTextBoxEmail.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBoxEmail.TabIndex = 8;
            // 
            // kryptonTextBoxHoTen
            // 
            this.kryptonTextBoxHoTen.Location = new System.Drawing.Point(31, 101);
            this.kryptonTextBoxHoTen.Name = "kryptonTextBoxHoTen";
            this.kryptonTextBoxHoTen.Size = new System.Drawing.Size(806, 29);
            this.kryptonTextBoxHoTen.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBoxHoTen.TabIndex = 7;
            // 
            // kryptonLabelQuocGia
            // 
            this.kryptonLabelQuocGia.Location = new System.Drawing.Point(476, 382);
            this.kryptonLabelQuocGia.Name = "kryptonLabelQuocGia";
            this.kryptonLabelQuocGia.Size = new System.Drawing.Size(134, 23);
            this.kryptonLabelQuocGia.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabelQuocGia.TabIndex = 6;
            this.kryptonLabelQuocGia.Values.Text = "Quốc gia cư trú *";
            // 
            // kryptonLabelSDT
            // 
            this.kryptonLabelSDT.Location = new System.Drawing.Point(33, 382);
            this.kryptonLabelSDT.Name = "kryptonLabelSDT";
            this.kryptonLabelSDT.Size = new System.Drawing.Size(126, 23);
            this.kryptonLabelSDT.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabelSDT.TabIndex = 5;
            this.kryptonLabelSDT.Values.Text = "Số Điện Thoại *";
            // 
            // kryptonLabel5
            // 
            this.kryptonLabel5.Location = new System.Drawing.Point(31, 305);
            this.kryptonLabel5.Name = "kryptonLabel5";
            this.kryptonLabel5.Size = new System.Drawing.Size(6, 2);
            this.kryptonLabel5.StateCommon.ShortText.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabel5.TabIndex = 4;
            this.kryptonLabel5.Values.Text = "";
            // 
            // kryptonLabelNhapLaiEmail
            // 
            this.kryptonLabelNhapLaiEmail.Location = new System.Drawing.Point(31, 234);
            this.kryptonLabelNhapLaiEmail.Name = "kryptonLabelNhapLaiEmail";
            this.kryptonLabelNhapLaiEmail.Size = new System.Drawing.Size(127, 23);
            this.kryptonLabelNhapLaiEmail.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabelNhapLaiEmail.TabIndex = 3;
            this.kryptonLabelNhapLaiEmail.Values.Text = "Nhập lại email *";
            // 
            // kryptonLabelEmail
            // 
            this.kryptonLabelEmail.Location = new System.Drawing.Point(31, 153);
            this.kryptonLabelEmail.Name = "kryptonLabelEmail";
            this.kryptonLabelEmail.Size = new System.Drawing.Size(64, 23);
            this.kryptonLabelEmail.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabelEmail.TabIndex = 2;
            this.kryptonLabelEmail.Values.Text = "Email *";
            // 
            // kryptonLabelHoTen
            // 
            this.kryptonLabelHoTen.Location = new System.Drawing.Point(31, 75);
            this.kryptonLabelHoTen.Name = "kryptonLabelHoTen";
            this.kryptonLabelHoTen.Size = new System.Drawing.Size(233, 23);
            this.kryptonLabelHoTen.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabelHoTen.TabIndex = 1;
            this.kryptonLabelHoTen.Values.Text = "Họ và tên như trong hộ chiếu *";
            // 
            // kryptonLabel1
            // 
            this.kryptonLabel1.Location = new System.Drawing.Point(31, 36);
            this.kryptonLabel1.Name = "kryptonLabel1";
            this.kryptonLabel1.Size = new System.Drawing.Size(320, 29);
            this.kryptonLabel1.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonLabel1.TabIndex = 0;
            this.kryptonLabel1.Values.Text = "Vui lòng điền thông tin của bạn";
            // 
            // FormDatPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1484, 861);
            this.Controls.Add(this.kryptonGroupThongTinCaNhan);
            this.Name = "FormDatPhong";
            this.Palette = this.kryptonPaletteDatPhong;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormDatPhong";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupThongTinCaNhan.Panel)).EndInit();
            this.kryptonGroupThongTinCaNhan.Panel.ResumeLayout(false);
            this.kryptonGroupThongTinCaNhan.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupThongTinCaNhan)).EndInit();
            this.kryptonGroupThongTinCaNhan.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPaletteDatPhong;
        private ComponentFactory.Krypton.Toolkit.KryptonGroup kryptonGroupThongTinCaNhan;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelQuocGia;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSDT;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabel5;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelNhapLaiEmail;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEmail;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelHoTen;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabel1;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSDT;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxNhapLaiEmail;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEmail;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxHoTen;
        private ComponentFactory.Krypton.Toolkit.KryptonDropButton kryptonDropButtonQuocGia;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDatPhong;
        private System.Windows.Forms.Label label1;
    }
}