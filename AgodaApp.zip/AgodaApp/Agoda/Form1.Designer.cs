﻿namespace Agoda
{
    partial class FormHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonPaletteHome = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.kryptonPanelThanhCongCu = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonButtonDangKy = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButtonDangNhap = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.kryptonGroupSearch = new ComponentFactory.Krypton.Toolkit.KryptonGroup();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.kryptonButtonSoNguoiPhong = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonGroupSoNguoiPhong = new ComponentFactory.Krypton.Toolkit.KryptonGroup();
            this.labelSoNguoi = new System.Windows.Forms.Label();
            this.labelSoPhong = new System.Windows.Forms.Label();
            this.pictureBoxTruNguoi = new System.Windows.Forms.PictureBox();
            this.pictureBoxCongNguoi = new System.Windows.Forms.PictureBox();
            this.pictureBoxTruPhong = new System.Windows.Forms.PictureBox();
            this.pictureBoxCongPhong = new System.Windows.Forms.PictureBox();
            this.labelNguoi = new System.Windows.Forms.Label();
            this.labelPhong = new System.Windows.Forms.Label();
            this.kryptonButtonTim = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonDateTimePickerDi = new ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker();
            this.kryptonDateTimePickerDen = new ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker();
            this.kryptonTextBoxSearch = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelThanhDuoi = new System.Windows.Forms.Panel();
            this.labelThanhDuoi = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2ThanhDuoi = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanelThanhCongCu)).BeginInit();
            this.kryptonPanelThanhCongCu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSearch.Panel)).BeginInit();
            this.kryptonGroupSearch.Panel.SuspendLayout();
            this.kryptonGroupSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSoNguoiPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSoNguoiPhong.Panel)).BeginInit();
            this.kryptonGroupSoNguoiPhong.Panel.SuspendLayout();
            this.kryptonGroupSoNguoiPhong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTruNguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCongNguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTruPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCongPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelThanhDuoi.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPaletteHome
            // 
            this.kryptonPaletteHome.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteHome.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteHome.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPaletteHome.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this.kryptonPaletteHome.HeaderStyles.HeaderCommon.StateCommon.ButtonPadding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            this.kryptonPaletteHome.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonPaletteHome.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonPaletteHome.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 12;
            // 
            // kryptonPanelThanhCongCu
            // 
            this.kryptonPanelThanhCongCu.Controls.Add(this.kryptonButtonDangKy);
            this.kryptonPanelThanhCongCu.Controls.Add(this.kryptonButtonDangNhap);
            this.kryptonPanelThanhCongCu.Controls.Add(this.pictureBoxLogo);
            this.kryptonPanelThanhCongCu.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonPanelThanhCongCu.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanelThanhCongCu.Name = "kryptonPanelThanhCongCu";
            this.kryptonPanelThanhCongCu.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.kryptonPanelThanhCongCu.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonLowProfile;
            this.kryptonPanelThanhCongCu.Size = new System.Drawing.Size(1484, 60);
            this.kryptonPanelThanhCongCu.TabIndex = 1;
            // 
            // kryptonButtonDangKy
            // 
            this.kryptonButtonDangKy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.kryptonButtonDangKy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonDangKy.Location = new System.Drawing.Point(1317, 3);
            this.kryptonButtonDangKy.Name = "kryptonButtonDangKy";
            this.kryptonButtonDangKy.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonButtonDangKy.Size = new System.Drawing.Size(133, 45);
            this.kryptonButtonDangKy.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonButtonDangKy.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonButtonDangKy.StateCommon.Border.Color1 = System.Drawing.Color.Aqua;
            this.kryptonButtonDangKy.StateCommon.Border.Color2 = System.Drawing.Color.Aqua;
            this.kryptonButtonDangKy.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonDangKy.StateCommon.Border.Rounding = 20;
            this.kryptonButtonDangKy.StateCommon.Border.Width = 1;
            this.kryptonButtonDangKy.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.LightCoral;
            this.kryptonButtonDangKy.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonDangKy.StateCommon.Content.ShortText.Hint = ComponentFactory.Krypton.Toolkit.PaletteTextHint.AntiAlias;
            this.kryptonButtonDangKy.TabIndex = 2;
            this.kryptonButtonDangKy.Values.Text = "Đăng Ký";
            this.kryptonButtonDangKy.Click += new System.EventHandler(this.kryptonButtonDangKy_Click);
            // 
            // kryptonButtonDangNhap
            // 
            this.kryptonButtonDangNhap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.kryptonButtonDangNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonDangNhap.Location = new System.Drawing.Point(1178, 3);
            this.kryptonButtonDangNhap.Name = "kryptonButtonDangNhap";
            this.kryptonButtonDangNhap.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonButtonDangNhap.Size = new System.Drawing.Size(133, 45);
            this.kryptonButtonDangNhap.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonButtonDangNhap.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonButtonDangNhap.StateCommon.Border.Color1 = System.Drawing.Color.Coral;
            this.kryptonButtonDangNhap.StateCommon.Border.Color2 = System.Drawing.Color.Aqua;
            this.kryptonButtonDangNhap.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonDangNhap.StateCommon.Border.Rounding = 20;
            this.kryptonButtonDangNhap.StateCommon.Border.Width = 1;
            this.kryptonButtonDangNhap.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.DodgerBlue;
            this.kryptonButtonDangNhap.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonDangNhap.StateCommon.Content.ShortText.Hint = ComponentFactory.Krypton.Toolkit.PaletteTextHint.AntiAlias;
            this.kryptonButtonDangNhap.TabIndex = 1;
            this.kryptonButtonDangNhap.Values.Text = "Đăng nhập";
            this.kryptonButtonDangNhap.Click += new System.EventHandler(this.kryptonButtonDangNhap_Click);
            this.kryptonButtonDangNhap.MouseEnter += new System.EventHandler(this.kryptonButtonDangNhap_MouseEnter);
            this.kryptonButtonDangNhap.MouseLeave += new System.EventHandler(this.kryptonButtonDangNhap_MouseLeave);
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Image = global::Agoda.Properties.Resources.Agoda_logo;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(125, 57);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // kryptonGroupSearch
            // 
            this.kryptonGroupSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.kryptonGroupSearch.GroupBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonGallery;
            this.kryptonGroupSearch.Location = new System.Drawing.Point(233, 308);
            this.kryptonGroupSearch.Name = "kryptonGroupSearch";
            this.kryptonGroupSearch.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            // 
            // kryptonGroupSearch.Panel
            // 
            this.kryptonGroupSearch.Panel.Controls.Add(this.pictureBoxSearch);
            this.kryptonGroupSearch.Panel.Controls.Add(this.kryptonButtonSoNguoiPhong);
            this.kryptonGroupSearch.Panel.Controls.Add(this.kryptonGroupSoNguoiPhong);
            this.kryptonGroupSearch.Panel.Controls.Add(this.kryptonButtonTim);
            this.kryptonGroupSearch.Panel.Controls.Add(this.kryptonDateTimePickerDi);
            this.kryptonGroupSearch.Panel.Controls.Add(this.kryptonDateTimePickerDen);
            this.kryptonGroupSearch.Panel.Controls.Add(this.kryptonTextBoxSearch);
            this.kryptonGroupSearch.Size = new System.Drawing.Size(1000, 320);
            this.kryptonGroupSearch.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonGroupSearch.StateCommon.Back.Color2 = System.Drawing.Color.DeepSkyBlue;
            this.kryptonGroupSearch.StateCommon.Border.Color1 = System.Drawing.Color.DodgerBlue;
            this.kryptonGroupSearch.StateCommon.Border.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.GlassCheckedTrackingFull;
            this.kryptonGroupSearch.StateCommon.Border.Draw = ComponentFactory.Krypton.Toolkit.InheritBool.True;
            this.kryptonGroupSearch.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonGroupSearch.StateCommon.Border.ImageStyle = ComponentFactory.Krypton.Toolkit.PaletteImageStyle.Stretch;
            this.kryptonGroupSearch.StateCommon.Border.Rounding = 20;
            this.kryptonGroupSearch.StateDisabled.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonGroupSearch.TabIndex = 3;
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBoxSearch.Image = global::Agoda.Properties.Resources.search_icon;
            this.pictureBoxSearch.Location = new System.Drawing.Point(116, 75);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(40, 40);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSearch.TabIndex = 7;
            this.pictureBoxSearch.TabStop = false;
            // 
            // kryptonButtonSoNguoiPhong
            // 
            this.kryptonButtonSoNguoiPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonSoNguoiPhong.Location = new System.Drawing.Point(510, 155);
            this.kryptonButtonSoNguoiPhong.Name = "kryptonButtonSoNguoiPhong";
            this.kryptonButtonSoNguoiPhong.Size = new System.Drawing.Size(358, 42);
            this.kryptonButtonSoNguoiPhong.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonSoNguoiPhong.StateCommon.Border.Rounding = 10;
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, 5, -1);
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.Black;
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.Black;
            this.kryptonButtonSoNguoiPhong.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonSoNguoiPhong.TabIndex = 6;
            this.kryptonButtonSoNguoiPhong.Values.Text = "2 người, 1 phòng";
            this.kryptonButtonSoNguoiPhong.Click += new System.EventHandler(this.kryptonButtonSoNguoiPhong_Click);
            // 
            // kryptonGroupSoNguoiPhong
            // 
            this.kryptonGroupSoNguoiPhong.Location = new System.Drawing.Point(510, 203);
            this.kryptonGroupSoNguoiPhong.Name = "kryptonGroupSoNguoiPhong";
            // 
            // kryptonGroupSoNguoiPhong.Panel
            // 
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.labelSoNguoi);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.labelSoPhong);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.pictureBoxTruNguoi);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.pictureBoxCongNguoi);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.pictureBoxTruPhong);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.pictureBoxCongPhong);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.labelNguoi);
            this.kryptonGroupSoNguoiPhong.Panel.Controls.Add(this.labelPhong);
            this.kryptonGroupSoNguoiPhong.Size = new System.Drawing.Size(260, 100);
            this.kryptonGroupSoNguoiPhong.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonGroupSoNguoiPhong.StateCommon.Back.Color2 = System.Drawing.Color.White;
            this.kryptonGroupSoNguoiPhong.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonGroupSoNguoiPhong.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonGroupSoNguoiPhong.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonGroupSoNguoiPhong.StateCommon.Border.Rounding = 10;
            this.kryptonGroupSoNguoiPhong.TabIndex = 5;
            // 
            // labelSoNguoi
            // 
            this.labelSoNguoi.AutoSize = true;
            this.labelSoNguoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoNguoi.Location = new System.Drawing.Point(135, 52);
            this.labelSoNguoi.Name = "labelSoNguoi";
            this.labelSoNguoi.Size = new System.Drawing.Size(18, 20);
            this.labelSoNguoi.TabIndex = 7;
            this.labelSoNguoi.Text = "2";
            // 
            // labelSoPhong
            // 
            this.labelSoPhong.AutoSize = true;
            this.labelSoPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoPhong.Location = new System.Drawing.Point(135, 10);
            this.labelSoPhong.Name = "labelSoPhong";
            this.labelSoPhong.Size = new System.Drawing.Size(18, 20);
            this.labelSoPhong.TabIndex = 6;
            this.labelSoPhong.Text = "1";
            // 
            // pictureBoxTruNguoi
            // 
            this.pictureBoxTruNguoi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTruNguoi.Image = global::Agoda.Properties.Resources.dau_tru_icon;
            this.pictureBoxTruNguoi.Location = new System.Drawing.Point(89, 50);
            this.pictureBoxTruNguoi.Name = "pictureBoxTruNguoi";
            this.pictureBoxTruNguoi.Size = new System.Drawing.Size(22, 22);
            this.pictureBoxTruNguoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTruNguoi.TabIndex = 5;
            this.pictureBoxTruNguoi.TabStop = false;
            this.pictureBoxTruNguoi.Click += new System.EventHandler(this.pictureBoxTruNguoi_Click);
            // 
            // pictureBoxCongNguoi
            // 
            this.pictureBoxCongNguoi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxCongNguoi.Image = global::Agoda.Properties.Resources.add_icon;
            this.pictureBoxCongNguoi.Location = new System.Drawing.Point(177, 50);
            this.pictureBoxCongNguoi.Name = "pictureBoxCongNguoi";
            this.pictureBoxCongNguoi.Size = new System.Drawing.Size(22, 22);
            this.pictureBoxCongNguoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCongNguoi.TabIndex = 4;
            this.pictureBoxCongNguoi.TabStop = false;
            this.pictureBoxCongNguoi.Click += new System.EventHandler(this.pictureBoxCongNguoi_Click);
            // 
            // pictureBoxTruPhong
            // 
            this.pictureBoxTruPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTruPhong.Image = global::Agoda.Properties.Resources.dau_tru_icon;
            this.pictureBoxTruPhong.Location = new System.Drawing.Point(89, 8);
            this.pictureBoxTruPhong.Name = "pictureBoxTruPhong";
            this.pictureBoxTruPhong.Size = new System.Drawing.Size(22, 22);
            this.pictureBoxTruPhong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTruPhong.TabIndex = 3;
            this.pictureBoxTruPhong.TabStop = false;
            this.pictureBoxTruPhong.Click += new System.EventHandler(this.pictureBoxTruPhong_Click);
            // 
            // pictureBoxCongPhong
            // 
            this.pictureBoxCongPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxCongPhong.Image = global::Agoda.Properties.Resources.add_icon;
            this.pictureBoxCongPhong.Location = new System.Drawing.Point(177, 8);
            this.pictureBoxCongPhong.Name = "pictureBoxCongPhong";
            this.pictureBoxCongPhong.Size = new System.Drawing.Size(22, 22);
            this.pictureBoxCongPhong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCongPhong.TabIndex = 2;
            this.pictureBoxCongPhong.TabStop = false;
            this.pictureBoxCongPhong.Click += new System.EventHandler(this.pictureBoxCongPhong_Click);
            // 
            // labelNguoi
            // 
            this.labelNguoi.AutoSize = true;
            this.labelNguoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNguoi.Location = new System.Drawing.Point(14, 58);
            this.labelNguoi.Name = "labelNguoi";
            this.labelNguoi.Size = new System.Drawing.Size(48, 16);
            this.labelNguoi.TabIndex = 1;
            this.labelNguoi.Text = "Người";
            // 
            // labelPhong
            // 
            this.labelPhong.AutoSize = true;
            this.labelPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPhong.Location = new System.Drawing.Point(11, 16);
            this.labelPhong.Name = "labelPhong";
            this.labelPhong.Size = new System.Drawing.Size(51, 16);
            this.labelPhong.TabIndex = 0;
            this.labelPhong.Text = "Phòng";
            // 
            // kryptonButtonTim
            // 
            this.kryptonButtonTim.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonButtonTim.Location = new System.Drawing.Point(287, 239);
            this.kryptonButtonTim.Name = "kryptonButtonTim";
            this.kryptonButtonTim.Size = new System.Drawing.Size(426, 50);
            this.kryptonButtonTim.StateCommon.Back.Color1 = System.Drawing.Color.DodgerBlue;
            this.kryptonButtonTim.StateCommon.Back.Color2 = System.Drawing.Color.DodgerBlue;
            this.kryptonButtonTim.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButtonTim.StateCommon.Border.Rounding = 10;
            this.kryptonButtonTim.StateCommon.Border.Width = 1;
            this.kryptonButtonTim.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.kryptonButtonTim.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButtonTim.TabIndex = 4;
            this.kryptonButtonTim.Values.Text = "Tìm";
            this.kryptonButtonTim.Click += new System.EventHandler(this.kryptonButtonTim_Click);
            // 
            // kryptonDateTimePickerDi
            // 
            this.kryptonDateTimePickerDi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonDateTimePickerDi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.kryptonDateTimePickerDi.Location = new System.Drawing.Point(307, 155);
            this.kryptonDateTimePickerDi.Name = "kryptonDateTimePickerDi";
            this.kryptonDateTimePickerDi.Size = new System.Drawing.Size(175, 42);
            this.kryptonDateTimePickerDi.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonDateTimePickerDi.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonDateTimePickerDi.StateCommon.Border.Rounding = 10;
            this.kryptonDateTimePickerDi.StateCommon.Border.Width = 1;
            this.kryptonDateTimePickerDi.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonDateTimePickerDi.TabIndex = 2;
            // 
            // kryptonDateTimePickerDen
            // 
            this.kryptonDateTimePickerDen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kryptonDateTimePickerDen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.kryptonDateTimePickerDen.Location = new System.Drawing.Point(104, 155);
            this.kryptonDateTimePickerDen.Name = "kryptonDateTimePickerDen";
            this.kryptonDateTimePickerDen.Size = new System.Drawing.Size(175, 42);
            this.kryptonDateTimePickerDen.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonDateTimePickerDen.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonDateTimePickerDen.StateCommon.Border.Rounding = 10;
            this.kryptonDateTimePickerDen.StateCommon.Border.Width = 1;
            this.kryptonDateTimePickerDen.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonDateTimePickerDen.TabIndex = 1;
            // 
            // kryptonTextBoxSearch
            // 
            this.kryptonTextBoxSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.kryptonTextBoxSearch.Location = new System.Drawing.Point(104, 67);
            this.kryptonTextBoxSearch.Multiline = true;
            this.kryptonTextBoxSearch.Name = "kryptonTextBoxSearch";
            this.kryptonTextBoxSearch.Size = new System.Drawing.Size(764, 58);
            this.kryptonTextBoxSearch.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.kryptonTextBoxSearch.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonTextBoxSearch.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonTextBoxSearch.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBoxSearch.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonTextBoxSearch.StateCommon.Border.Rounding = 10;
            this.kryptonTextBoxSearch.StateCommon.Border.Width = 1;
            this.kryptonTextBoxSearch.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.kryptonTextBoxSearch.StateCommon.Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBoxSearch.StateCommon.Content.Padding = new System.Windows.Forms.Padding(70, 13, 10, 10);
            this.kryptonTextBoxSearch.TabIndex = 0;
            this.kryptonTextBoxSearch.Text = "Nhập địa điểm du lịch hoặc tên khách sạn";
            this.kryptonTextBoxSearch.Enter += new System.EventHandler(this.kryptonTextBoxSearch_Enter);
            this.kryptonTextBoxSearch.Leave += new System.EventHandler(this.kryptonTextBoxSearch_Leave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox2.Image = global::Agoda.Properties.Resources.background;
            this.pictureBox2.Location = new System.Drawing.Point(0, 60);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1484, 452);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panelThanhDuoi
            // 
            this.panelThanhDuoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(46)))));
            this.panelThanhDuoi.Controls.Add(this.panel1);
            this.panelThanhDuoi.Controls.Add(this.labelThanhDuoi);
            this.panelThanhDuoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelThanhDuoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelThanhDuoi.Location = new System.Drawing.Point(0, 728);
            this.panelThanhDuoi.Name = "panelThanhDuoi";
            this.panelThanhDuoi.Size = new System.Drawing.Size(1484, 133);
            this.panelThanhDuoi.TabIndex = 4;
            // 
            // labelThanhDuoi
            // 
            this.labelThanhDuoi.AutoSize = true;
            this.labelThanhDuoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThanhDuoi.ForeColor = System.Drawing.Color.White;
            this.labelThanhDuoi.Location = new System.Drawing.Point(236, 29);
            this.labelThanhDuoi.Name = "labelThanhDuoi";
            this.labelThanhDuoi.Size = new System.Drawing.Size(997, 20);
            this.labelThanhDuoi.TabIndex = 0;
            this.labelThanhDuoi.Text = "Agoda.com là thành viên của Tập đoàn Booking Holdings, nhà cung cấp dịch vụ du lị" +
    "ch trực tuyến & các dịch vụ có liên quan hàng đầu thế giới.";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(46)))));
            this.panel1.Controls.Add(this.label2ThanhDuoi);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1484, 133);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(236, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(997, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Agoda.com là thành viên của Tập đoàn Booking Holdings, nhà cung cấp dịch vụ du lị" +
    "ch trực tuyến & các dịch vụ có liên quan hàng đầu thế giới.";
            // 
            // label2ThanhDuoi
            // 
            this.label2ThanhDuoi.AutoSize = true;
            this.label2ThanhDuoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2ThanhDuoi.ForeColor = System.Drawing.Color.White;
            this.label2ThanhDuoi.Location = new System.Drawing.Point(430, 76);
            this.label2ThanhDuoi.Name = "label2ThanhDuoi";
            this.label2ThanhDuoi.Size = new System.Drawing.Size(624, 20);
            this.label2ThanhDuoi.TabIndex = 1;
            this.label2ThanhDuoi.Text = "Mọi nội dung tại đây © 2005 – 2023 Công ty TNHH Tư nhân Agoda. Bảo Lưu Mọi Quyền." +
    "";
            // 
            // FormHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1484, 861);
            this.Controls.Add(this.panelThanhDuoi);
            this.Controls.Add(this.kryptonGroupSearch);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.kryptonPanelThanhCongCu);
            this.Name = "FormHome";
            this.Palette = this.kryptonPaletteHome;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanelThanhCongCu)).EndInit();
            this.kryptonPanelThanhCongCu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSearch.Panel)).EndInit();
            this.kryptonGroupSearch.Panel.ResumeLayout(false);
            this.kryptonGroupSearch.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSearch)).EndInit();
            this.kryptonGroupSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSoNguoiPhong.Panel)).EndInit();
            this.kryptonGroupSoNguoiPhong.Panel.ResumeLayout(false);
            this.kryptonGroupSoNguoiPhong.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonGroupSoNguoiPhong)).EndInit();
            this.kryptonGroupSoNguoiPhong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTruNguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCongNguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTruPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCongPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelThanhDuoi.ResumeLayout(false);
            this.panelThanhDuoi.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPaletteHome;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanelThanhCongCu;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDangNhap;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDangKy;
        private System.Windows.Forms.PictureBox pictureBox2;
        private ComponentFactory.Krypton.Toolkit.KryptonGroup kryptonGroupSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker kryptonDateTimePickerDen;
        private ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker kryptonDateTimePickerDi;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonTim;
        private ComponentFactory.Krypton.Toolkit.KryptonGroup kryptonGroupSoNguoiPhong;
        private System.Windows.Forms.Label labelNguoi;
        private System.Windows.Forms.Label labelPhong;
        private System.Windows.Forms.PictureBox pictureBoxCongPhong;
        private System.Windows.Forms.PictureBox pictureBoxTruNguoi;
        private System.Windows.Forms.PictureBox pictureBoxCongNguoi;
        private System.Windows.Forms.PictureBox pictureBoxTruPhong;
        private System.Windows.Forms.Label labelSoPhong;
        private System.Windows.Forms.Label labelSoNguoi;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonSoNguoiPhong;
        private System.Windows.Forms.PictureBox pictureBoxSearch;
        private System.Windows.Forms.Panel panelThanhDuoi;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2ThanhDuoi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelThanhDuoi;
    }
}

