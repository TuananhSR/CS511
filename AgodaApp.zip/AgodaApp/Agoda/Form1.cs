﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Agoda
{
    public partial class FormHome : KryptonForm
    {
        public FormHome()
        {
            InitializeComponent();
            kryptonGroupSoNguoiPhong.Visible = false;
            SetNoActiveControl(); // Gọi hàm để đặt control không được chọn
        }

        private void SetNoActiveControl()
        {
            // Đặt ActiveControl về null để không có control nào được chọn ban đầu
            this.ActiveControl = null;
        }

        private void kryptonButtonTim_Click(object sender, EventArgs e)
        {
            {
                this.Hide();
                FormListRoom sistema = new FormListRoom();
                sistema.ShowDialog();
                this.Close();
            }
        }

        private bool groupBoxVisible = false;


        private void kryptonButtonSoNguoiPhong_Click(object sender, EventArgs e)
        {
            // Nếu GroupBox đang ẩn, hiển thị nó; ngược lại, ẩn nó.
            kryptonGroupSoNguoiPhong.Visible = !groupBoxVisible;

            // Cập nhật trạng thái của biến cờ
            groupBoxVisible = !groupBoxVisible;

            UpdateLabelSoNguoiPhong();
        }

        private void kryptonTextBoxSearch_Enter(object sender, EventArgs e)
        {
            if (kryptonTextBoxSearch.Text == "Nhập địa điểm du lịch hoặc tên khách sạn")
            {
                kryptonTextBoxSearch.Text = "";
                kryptonTextBoxSearch.ForeColor = Color.Black;
            }
        }

        private void kryptonTextBoxSearch_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(kryptonTextBoxSearch.Text))
            {
                kryptonTextBoxSearch.Text = "Nhập địa điểm du lịch hoặc tên khách sạn";
                kryptonTextBoxSearch.ForeColor = Color.Gray;
            }
        }

        private int counterSoPhong = 1;
        private void pictureBoxCongPhong_Click(object sender, EventArgs e)
        {
            // Tăng giá trị của biến đếm khi được nhấn
            counterSoPhong++;
            UpdateLabelSoPhong();
        }

        private void pictureBoxTruPhong_Click(object sender, EventArgs e)
        {
            // Giảm giá trị của biến đếm khi  được nhấn
            counterSoPhong--;
            UpdateLabelSoPhong();
        }

        private void UpdateLabelSoPhong()
        {
            // Hiển thị giá trị của biến đếm trong Label
            labelSoPhong.Text = counterSoPhong.ToString();
        }

        private int counterSoNguoi = 2;
        private void pictureBoxTruNguoi_Click(object sender, EventArgs e)
        {
            counterSoNguoi--;
            UpdateLabelSoNguoi();

        }

        private void UpdateLabelSoNguoi()
        {
            // Hiển thị giá trị của biến đếm trong Label
            labelSoNguoi.Text = counterSoNguoi.ToString();
        }

        private void pictureBoxCongNguoi_Click(object sender, EventArgs e)
        {
            counterSoNguoi++;
            UpdateLabelSoNguoi();
        }

        private void UpdateLabelSoNguoiPhong()
        {
            // Số người và số phòng từ các Label2 và Label3
            string soNguoi = labelSoNguoi.Text;
            string soPhong = labelSoPhong.Text;

            // Định dạng lại chuỗi cho Label1
            kryptonButtonSoNguoiPhong.Text = $"{soNguoi} người, {soPhong} phòng";
        }

        private void kryptonButtonDangNhap_MouseEnter(object sender, EventArgs e)
        {
            kryptonButtonDangNhap.BackColor = Color.Orange;
        }

        private void kryptonButtonDangNhap_MouseLeave(object sender, EventArgs e)
        {
            kryptonButtonDangNhap.BackColor = Color.White;
        }

        private void kryptonButtonDangNhap_Click(object sender, EventArgs e)
        {
            {
                this.Hide();
                FormDangNhap sistema = new FormDangNhap();
                sistema.ShowDialog();
                this.Close();
            }
        }

        private void kryptonButtonDangKy_Click(object sender, EventArgs e)
        {
            {
                this.Hide();
                FormDangKi sistema = new FormDangKi();
                sistema.ShowDialog();
                this.Close();
            }
        }
    }
}
