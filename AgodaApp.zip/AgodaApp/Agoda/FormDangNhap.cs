﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Agoda
{
    public partial class FormDangNhap : KryptonForm
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void kryptonTextBoxEmail_Enter(object sender, EventArgs e)
        {
            if (kryptonTextBoxEmail.Text == "Email/Số điện thoại")
            {
                kryptonTextBoxEmail.Text = "";
                kryptonTextBoxEmail.ForeColor = Color.Black;
            }
        }

        private void kryptonTextBoxEmail_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(kryptonTextBoxEmail.Text))
            {
                kryptonTextBoxEmail.Text = "Email/Số điện thoại";
                kryptonTextBoxEmail.ForeColor = Color.Gray;
            }
        }

        private void kryptonTextBoxMatKhau_Enter(object sender, EventArgs e)
        {
            if (kryptonTextBoxMatKhau.Text == "Mật khẩu")
            {
                kryptonTextBoxMatKhau.PasswordChar = '*';
                kryptonTextBoxMatKhau.Text = "";
                kryptonTextBoxMatKhau.ForeColor = Color.Black;
            }
        }

        private void kryptonTextBoxMatKhau_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(kryptonTextBoxMatKhau.Text))
            {
                kryptonTextBoxMatKhau.PasswordChar = '\0';
                kryptonTextBoxMatKhau.Text = "Mật khẩu";
                kryptonTextBoxMatKhau.ForeColor = Color.Gray;
            }
        }

        private void FormDangNhap_Load(object sender, EventArgs e)
        {
            kryptonTextBoxMatKhau.Text = "Mật khẩu";
            kryptonTextBoxMatKhau.ForeColor = Color.Gray;

            kryptonTextBoxEmail.Text = "Email/Số điện thoại";
            kryptonTextBoxEmail.ForeColor = Color.Gray;

            pictureBoxHien.Visible = true;
            pictureBoxAn.Visible = false;
        }

        private void pictureBoxHien_Click(object sender, EventArgs e)
        {
            kryptonTextBoxMatKhau.PasswordChar = '\0';
            pictureBoxHien.Visible = false;
            pictureBoxAn.Visible = true;
        }

        private void pictureBoxAn_Click(object sender, EventArgs e)
        {
            kryptonTextBoxMatKhau.PasswordChar = '*';
            pictureBoxAn.Visible = false;
            pictureBoxHien.Visible = true;
        }

        private void labelTaoTaiKhoan_Click(object sender, EventArgs e)
        {
            {
                this.Hide();
                FormDangKi sistema = new FormDangKi();
                sistema.ShowDialog();
                this.Close();
            }
        }

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
            {
                this.Hide();
                FormHome sistema = new FormHome();
                sistema.ShowDialog();
                this.Close();
            }
        }
    }
}
