﻿namespace Agoda
{
    partial class UserControlPhong
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonPalette1 = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelTenHotel = new System.Windows.Forms.Label();
            this.labelDiaChi = new System.Windows.Forms.Label();
            this.labelGia = new System.Windows.Forms.Label();
            this.labelSao = new System.Windows.Forms.Label();
            this.labelDanhGia = new System.Windows.Forms.Label();
            this.labelTextGia = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPalette1
            // 
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Color1 = System.Drawing.Color.White;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Color2 = System.Drawing.Color.White;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 12;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(25, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 200);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelTenHotel
            // 
            this.labelTenHotel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenHotel.Location = new System.Drawing.Point(247, 14);
            this.labelTenHotel.Name = "labelTenHotel";
            this.labelTenHotel.Size = new System.Drawing.Size(268, 34);
            this.labelTenHotel.TabIndex = 1;
            this.labelTenHotel.Text = "Khách sạn Camy";
            // 
            // labelDiaChi
            // 
            this.labelDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDiaChi.ForeColor = System.Drawing.Color.Blue;
            this.labelDiaChi.Location = new System.Drawing.Point(248, 82);
            this.labelDiaChi.Name = "labelDiaChi";
            this.labelDiaChi.Size = new System.Drawing.Size(268, 34);
            this.labelDiaChi.TabIndex = 2;
            this.labelDiaChi.Text = "QL1K, Linh Xuân, Thủ Đức";
            // 
            // labelGia
            // 
            this.labelGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGia.ForeColor = System.Drawing.Color.Red;
            this.labelGia.Location = new System.Drawing.Point(545, 133);
            this.labelGia.Name = "labelGia";
            this.labelGia.Size = new System.Drawing.Size(208, 34);
            this.labelGia.TabIndex = 3;
            this.labelGia.Text = "200,000 VND";
            // 
            // labelSao
            // 
            this.labelSao.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSao.ForeColor = System.Drawing.Color.Yellow;
            this.labelSao.Location = new System.Drawing.Point(248, 39);
            this.labelSao.Name = "labelSao";
            this.labelSao.Size = new System.Drawing.Size(268, 34);
            this.labelSao.TabIndex = 4;
            this.labelSao.Text = "⭐⭐";
            // 
            // labelDanhGia
            // 
            this.labelDanhGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDanhGia.Location = new System.Drawing.Point(247, 133);
            this.labelDanhGia.Name = "labelDanhGia";
            this.labelDanhGia.Size = new System.Drawing.Size(268, 34);
            this.labelDanhGia.TabIndex = 5;
            this.labelDanhGia.Text = "Tuyệt vời";
            // 
            // labelTextGia
            // 
            this.labelTextGia.AutoSize = true;
            this.labelTextGia.Location = new System.Drawing.Point(547, 103);
            this.labelTextGia.Name = "labelTextGia";
            this.labelTextGia.Size = new System.Drawing.Size(78, 13);
            this.labelTextGia.TabIndex = 6;
            this.labelTextGia.Text = "Giá mỗi đêm từ";
            // 
            // UserControlPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.labelTextGia);
            this.Controls.Add(this.labelDanhGia);
            this.Controls.Add(this.labelSao);
            this.Controls.Add(this.labelGia);
            this.Controls.Add(this.labelDiaChi);
            this.Controls.Add(this.labelTenHotel);
            this.Controls.Add(this.pictureBox1);
            this.Name = "UserControlPhong";
            this.Size = new System.Drawing.Size(765, 220);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPalette1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelTenHotel;
        private System.Windows.Forms.Label labelDiaChi;
        private System.Windows.Forms.Label labelGia;
        private System.Windows.Forms.Label labelSao;
        private System.Windows.Forms.Label labelDanhGia;
        private System.Windows.Forms.Label labelTextGia;
    }
}
