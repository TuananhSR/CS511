﻿namespace Agoda
{
    partial class UserControlThongTinPhong
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTenPhong = new System.Windows.Forms.Label();
            this.labelLoaiPhong = new System.Windows.Forms.Label();
            this.labelSoGiuong = new System.Windows.Forms.Label();
            this.labelDienTich = new System.Windows.Forms.Label();
            this.labelHuong = new System.Windows.Forms.Label();
            this.labelSucChua = new System.Windows.Forms.Label();
            this.labelSoLuongSucChua = new System.Windows.Forms.Label();
            this.labelHuyBovaThanhToan = new System.Windows.Forms.Label();
            this.labelHuyBo = new System.Windows.Forms.Label();
            this.labelTextHuyBo = new System.Windows.Forms.Label();
            this.labelTextThanhToan = new System.Windows.Forms.Label();
            this.labelThanhToan = new System.Windows.Forms.Label();
            this.labelGiaPhong = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTenPhong
            // 
            this.labelTenPhong.AutoSize = true;
            this.labelTenPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenPhong.Location = new System.Drawing.Point(18, 20);
            this.labelTenPhong.Name = "labelTenPhong";
            this.labelTenPhong.Size = new System.Drawing.Size(175, 24);
            this.labelTenPhong.TabIndex = 0;
            this.labelTenPhong.Text = "Phòng tiêu chuẩn";
            // 
            // labelLoaiPhong
            // 
            this.labelLoaiPhong.AutoSize = true;
            this.labelLoaiPhong.Location = new System.Drawing.Point(19, 55);
            this.labelLoaiPhong.Name = "labelLoaiPhong";
            this.labelLoaiPhong.Size = new System.Drawing.Size(61, 13);
            this.labelLoaiPhong.TabIndex = 1;
            this.labelLoaiPhong.Text = "Loại Phòng";
            // 
            // labelSoGiuong
            // 
            this.labelSoGiuong.AutoSize = true;
            this.labelSoGiuong.Location = new System.Drawing.Point(19, 276);
            this.labelSoGiuong.Name = "labelSoGiuong";
            this.labelSoGiuong.Size = new System.Drawing.Size(66, 13);
            this.labelSoGiuong.TabIndex = 3;
            this.labelSoGiuong.Text = "1 giường đôi";
            // 
            // labelDienTich
            // 
            this.labelDienTich.AutoSize = true;
            this.labelDienTich.Location = new System.Drawing.Point(19, 308);
            this.labelDienTich.Name = "labelDienTich";
            this.labelDienTich.Size = new System.Drawing.Size(83, 13);
            this.labelDienTich.TabIndex = 4;
            this.labelDienTich.Text = "Diện tích: 16m2";
            // 
            // labelHuong
            // 
            this.labelHuong.AutoSize = true;
            this.labelHuong.Location = new System.Drawing.Point(19, 343);
            this.labelHuong.Name = "labelHuong";
            this.labelHuong.Size = new System.Drawing.Size(39, 13);
            this.labelHuong.TabIndex = 5;
            this.labelHuong.Text = "Hướng";
            // 
            // labelSucChua
            // 
            this.labelSucChua.AutoSize = true;
            this.labelSucChua.Location = new System.Drawing.Point(305, 55);
            this.labelSucChua.Name = "labelSucChua";
            this.labelSucChua.Size = new System.Drawing.Size(53, 13);
            this.labelSucChua.TabIndex = 6;
            this.labelSucChua.Text = "Sức chứa";
            // 
            // labelSoLuongSucChua
            // 
            this.labelSoLuongSucChua.AutoSize = true;
            this.labelSoLuongSucChua.Location = new System.Drawing.Point(305, 107);
            this.labelSoLuongSucChua.Name = "labelSoLuongSucChua";
            this.labelSoLuongSucChua.Size = new System.Drawing.Size(42, 13);
            this.labelSoLuongSucChua.TabIndex = 7;
            this.labelSoLuongSucChua.Text = "2 người";
            // 
            // labelHuyBovaThanhToan
            // 
            this.labelHuyBovaThanhToan.AutoSize = true;
            this.labelHuyBovaThanhToan.Location = new System.Drawing.Point(449, 55);
            this.labelHuyBovaThanhToan.Name = "labelHuyBovaThanhToan";
            this.labelHuyBovaThanhToan.Size = new System.Drawing.Size(112, 13);
            this.labelHuyBovaThanhToan.TabIndex = 8;
            this.labelHuyBovaThanhToan.Text = "Thanh toán và huỷ bỏ";
            // 
            // labelHuyBo
            // 
            this.labelHuyBo.AutoSize = true;
            this.labelHuyBo.Location = new System.Drawing.Point(452, 81);
            this.labelHuyBo.Name = "labelHuyBo";
            this.labelHuyBo.Size = new System.Drawing.Size(41, 13);
            this.labelHuyBo.TabIndex = 9;
            this.labelHuyBo.Text = "Huỷ bỏ";
            // 
            // labelTextHuyBo
            // 
            this.labelTextHuyBo.AutoSize = true;
            this.labelTextHuyBo.Location = new System.Drawing.Point(452, 120);
            this.labelTextHuyBo.Name = "labelTextHuyBo";
            this.labelTextHuyBo.Size = new System.Drawing.Size(170, 13);
            this.labelTextHuyBo.TabIndex = 10;
            this.labelTextHuyBo.Text = "Miễn phí huỷ trước ngày 6 tháng 1";
            // 
            // labelTextThanhToan
            // 
            this.labelTextThanhToan.AutoSize = true;
            this.labelTextThanhToan.Location = new System.Drawing.Point(452, 223);
            this.labelTextThanhToan.Name = "labelTextThanhToan";
            this.labelTextThanhToan.Size = new System.Drawing.Size(139, 13);
            this.labelTextThanhToan.TabIndex = 12;
            this.labelTextThanhToan.Text = "Thanh toán khi nhận phòng";
            // 
            // labelThanhToan
            // 
            this.labelThanhToan.AutoSize = true;
            this.labelThanhToan.Location = new System.Drawing.Point(452, 184);
            this.labelThanhToan.Name = "labelThanhToan";
            this.labelThanhToan.Size = new System.Drawing.Size(62, 13);
            this.labelThanhToan.TabIndex = 11;
            this.labelThanhToan.Text = "Thanh toán";
            // 
            // labelGiaPhong
            // 
            this.labelGiaPhong.AutoSize = true;
            this.labelGiaPhong.Location = new System.Drawing.Point(717, 55);
            this.labelGiaPhong.Name = "labelGiaPhong";
            this.labelGiaPhong.Size = new System.Drawing.Size(88, 13);
            this.labelGiaPhong.TabIndex = 13;
            this.labelGiaPhong.Text = "Giá phòng / đêm";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(22, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 170);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(308, 308);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(462, 1);
            this.panel1.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(22, 76);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 2);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(244, 81);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 300);
            this.panel3.TabIndex = 16;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Location = new System.Drawing.Point(398, 81);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 300);
            this.panel4.TabIndex = 17;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Location = new System.Drawing.Point(665, 81);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 300);
            this.panel5.TabIndex = 17;
            // 
            // UserControlThongTinPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelGiaPhong);
            this.Controls.Add(this.labelTextThanhToan);
            this.Controls.Add(this.labelThanhToan);
            this.Controls.Add(this.labelTextHuyBo);
            this.Controls.Add(this.labelHuyBo);
            this.Controls.Add(this.labelHuyBovaThanhToan);
            this.Controls.Add(this.labelSoLuongSucChua);
            this.Controls.Add(this.labelSucChua);
            this.Controls.Add(this.labelHuong);
            this.Controls.Add(this.labelDienTich);
            this.Controls.Add(this.labelSoGiuong);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelLoaiPhong);
            this.Controls.Add(this.labelTenPhong);
            this.Name = "UserControlThongTinPhong";
            this.Size = new System.Drawing.Size(845, 395);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTenPhong;
        private System.Windows.Forms.Label labelLoaiPhong;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelSoGiuong;
        private System.Windows.Forms.Label labelDienTich;
        private System.Windows.Forms.Label labelHuong;
        private System.Windows.Forms.Label labelSucChua;
        private System.Windows.Forms.Label labelSoLuongSucChua;
        private System.Windows.Forms.Label labelHuyBovaThanhToan;
        private System.Windows.Forms.Label labelHuyBo;
        private System.Windows.Forms.Label labelTextHuyBo;
        private System.Windows.Forms.Label labelTextThanhToan;
        private System.Windows.Forms.Label labelThanhToan;
        private System.Windows.Forms.Label labelGiaPhong;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}
